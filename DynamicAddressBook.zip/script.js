const addressForm = document.getElementById("addressForm");
const contactList = document.getElementById("contactList");

// Array to store contacts
let contacts = [];

// Event listener for form submission
addressForm.addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent page reload

    // Get form values
    const name = document.getElementById("name").value;
    const address = document.getElementById("address").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;

    // Save contact
    const contact = { name, address, email, phone };
    contacts.push(contact);

    // Reset form
    addressForm.reset();

    // Update contact list display
    displayContacts();
});

// Function to display contacts
function displayContacts() {
    contactList.innerHTML = ""; // Clear the list
    contacts.forEach((contact, index) => {
        const contactItem = document.createElement("div");
        contactItem.innerHTML = `
            <p><strong>${contact.name}</strong></p>
            <p>Address: ${contact.address}</p>
            <p>Email: ${contact.email}</p>
            <p>Phone: ${contact.phone}</p>
            <button onclick="deleteContact(${index})">Delete</button>
        `;
        contactList.appendChild(contactItem);
    });
}

// Function to delete a contact
function deleteContact(index) {
    contacts.splice(index, 1); // Remove from array
    displayContacts(); // Update the display
}
